Its an Ecommerce website created for the task for Rook Internship 

Home Page:
	1. Consists of various mobiles as products with the Name, Price , Order and Add to Cart option
	2. If order is selected it navigated to the address details page
	3. If Add to Cart is selected it navigated to Cart Page

Cart Page:
	1. Consists of products with Name, Increase, Decrease option and Quantity
	2. Checkout Button to navigate to Address page

Address Page:
	1. It requires details of the user and then it will gets authenticated by email otp in which the user has to type their email  and then Otp has to verified by the email
	got at GMail Account user entered on.
	2. then once you type your 6 digit pincode then the district and state will updated automatically.
	3. Once clicked next it moves to payment page.

Payment Page :
	1. Here we have to select the delivery type as Normal or Express Delivery
	2. Here we have to select the Payment type as Online or Cash on Delivery
	3. Here we can select Invoice by which invoice pdf will gets downloaded
	4. If Online Payment select Pay now to pay it online by razorpay gateway
	5. If cash on delivery select order now to confirm or place your Order

Order Page :
	1. Here details of your order will be displayed
	2. Confirmation mail would sent to you once order placed or confirmed.

Server Side :
	1. Once the order is placed the Order Details will be stored in the db.json.
	2. By the express js we can use POST menthod to store the details.

GitHub Link : https://github.com/Vignesh-S-18-2003/Rook_Internship

Hosted Link : https://668ebc41330b7a1783157715--endearing-kringle-619753.netlify.app/

Working Video : https://drive.google.com/file/d/1HxnmsG8-y8HODKXvKnsKWqoCGioFa5rN/view?usp=sharing